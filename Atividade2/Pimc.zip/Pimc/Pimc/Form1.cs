﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;
        string classificacao = "";
        public Form1()
        {
            InitializeComponent();

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = peso / Math.Pow(altura, 2);
            IMC = Math.Round(IMC, 1);
            mskbxIMC.Text = IMC.ToString("");

            if (IMC < 18.5)
                MessageBox.Show("magreza");
            else if (IMC <= 24.9)
                MessageBox.Show("Normal");
            else if (IMC <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (IMC <= 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade Grave");



        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            mskbxIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Digite valores válidos");
                mskbxPeso.Focus();

            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair) {
                return;
                    }

            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Digite valores válidos");
                mskbxAltura.Focus();
            }
        }
    }
}
      