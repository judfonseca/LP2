﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frnExercicio4 : Form
    {
        public frnExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while (posicao < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[posicao]))
                {
                    contaNum++; //contaNum+1 ou contaNum=contaNum+1
                }

                posicao++;
            }
            MessageBox.Show($"a frase tem {contaNum} números");
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            if (posicao == 0)
                MessageBox.Show("Não há caracteres em branco na frase.");
            else
                MessageBox.Show($"O 1º caracter em branco está na posição {posicao}");
        }

        private void btnContaLetra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;

            foreach (char letra in rchtxtFrase.Text)
            {
                if (char.IsLetter(letra))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"A frase tem {contaLetra} letras.");
        }
    }

}
