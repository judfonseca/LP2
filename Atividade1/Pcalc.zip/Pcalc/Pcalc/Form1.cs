﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class PCalc : Form

    {

        double Numero1, Numero2, Resultado;

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (Numero2 >= 0)
            {
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
            }
            
                                      
        

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Numero 2 Invalido");
                txtNumero2.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Numero 1 Invalido");
                txtNumero1.Focus();
            }
        }
        

        public PCalc()
        {
            InitializeComponent();
        }


    }
}
