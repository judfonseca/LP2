﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int Metade = txtPalavra2.Text.Length / 2;
            txtPalavra2.Text = txtPalavra2.Text.Substring(0, Metade) + txtPalavra1.Text + txtPalavra2.Text.Substring(Metade, txtPalavra2.Text.Length - Metade);
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int metade = txtPalavra1.Text.Length / 2;
            txtPalavra2.Text = txtPalavra1.Text.Insert(metade, "**");
        }

        private void btnCompara_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            if (palavra1 == palavra2)
            {
                MessageBox.Show("Palavras iguais");
            }
            else
            {
                MessageBox.Show("Palavras diferentes");
            }
        }
    }
}
