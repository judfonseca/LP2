﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int Numero1, Numero2;
        public frmExercicio5()

        {
            InitializeComponent();

        }


        private void btnSortear_Click(object sender, EventArgs e)
        {
            int Numero1 = 0;
            int Numero2 = 0;

                if (!int.TryParse(txtNumero1.Text, out Numero1) || Numero1 <= 0)
            
                {
                    MessageBox.Show("Numero 1 invalido");
                    txtNumero1.Focus();
                    return;
                }

                if (!int.TryParse(txtNumero2.Text, out Numero2) || Numero2 <= 0)
                {
                    MessageBox.Show("Numero 2 invalido");
                    txtNumero2.Focus();
                    return;
                }

                if (Numero2 <= Numero1)
                {
                MessageBox.Show("Numero 2 deve ser maior que Numero 1");
                txtNumero1.Focus();
                return;
                }
            
           
            Random ObjR = new Random();
            int Sorteado = ObjR.Next(Numero1, Numero2 +1);

            MessageBox.Show("Numero sorteado é:" + Sorteado);

            txtNumero1.Focus();
        }

    }
}
