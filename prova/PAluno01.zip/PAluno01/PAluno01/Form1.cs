﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[5, 3];
            string[] Alunos =
            {
                "Aluno 1", "Aluno 2", "Aluno 3", "Aluno 4", "Aluno 5"
            };
            double[] MediaAluno = new double[5];
            double MediaGeral = 0;

            for (int aluno = 0; aluno < 5; aluno++)
            {
                for (int professor = 0; professor < 3; professor++)
                {
                    string aux = Interaction.InputBox($"Digite a nota do {Alunos[aluno]} do Professor {professor + 1}", "Entrada de dados");

                    
                    if (double.TryParse(aux, out Notas[aluno, professor]) && Notas[aluno, professor] >= 0 && Notas[aluno,professor] <=10)
                    {
                        MediaAluno[aluno] += (Notas[aluno, professor])/3;
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido, digite um número de 0 a 10");
                        professor--;
                    }
                    if (aux == "")
                        return;
                    
                }
            }
            for (int aluno = 0; aluno < 5; aluno++)
            {
                for (int professor = 0; professor < 3; professor++)
                {
                    lstbxNotas.Items.Add($"{Alunos[aluno]}: Professor {professor +1}: {Notas[aluno, professor]}");
      
                }
                lstbxNotas.Items.Add($"Média {MediaAluno[aluno]:F2}");
                MediaGeral += (MediaAluno[aluno])/5;
            }

            lstbxNotas.Items.Add("Media Geral Alunos: " + MediaGeral.ToString("F2"));
            


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxNotas.Items.Clear();
        }
    }
}
