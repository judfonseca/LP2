﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class PTriangulo : Form
    {
        double ValorA, ValorB, ValorC;

        public PTriangulo()
        {
            InitializeComponent();
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out ValorB))
            {
                MessageBox.Show("Valor de B invalido!");
                Focus();
            }

        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out ValorC))
            {
                MessageBox.Show("Valor de C invalido!");
                Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
            


        }

        private void btnSair_Click(object sender, EventArgs e)
        {
           Close();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ValorA < (ValorB + ValorC)) && (ValorA > (Math.Abs(ValorB - ValorC))) &&
               (ValorB < (ValorA + ValorC)) && (ValorB > (Math.Abs(ValorA - ValorC))) &&
               (ValorC < (ValorA + ValorB)) && (ValorC > (Math.Abs(ValorA - ValorB))))
            {
                if ((ValorA == ValorB) && (ValorB == ValorC))
                    MessageBox.Show("Triangulo Equilatero");
                else if ((ValorA == ValorB) || (ValorB == ValorC) || (ValorA == ValorC))
                    MessageBox.Show("Triangulo Isosceles");
                else
                    MessageBox.Show("Triangulo Escaleno");
            }
             else
                MessageBox.Show("Nao forma um triangulo");
        }


        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text, out ValorA))
            {
                MessageBox.Show("Valor de A invalido!");
                Focus();
            }
        }
    }
}
